A Pen created at CodePen.io. You can find this one at http://codepen.io/adelbalso/pen/FwJcq.

 A basic CSS animation that makes a paper airplane fly out of this "Send" button when clicked.