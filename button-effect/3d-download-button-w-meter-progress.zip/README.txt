A Pen created at CodePen.io. You can find this one at http://codepen.io/tdevine33/pen/svupq.

 Animated download button (icon uses one i element) with 3D transition download meter progress bar.  Coded off of .sketch mockup file, attached:

https://docs.google.com/file/d/0B2_87exeIkPUaWhra2RacGx3MmM/edit?usp=sharing