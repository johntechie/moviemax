A Pen created at CodePen.io. You can find this one at http://codepen.io/soulwire/pen/bKens.

 Simulating squishy rubber (elastomer) buttons, inspired by designs on Dribbble