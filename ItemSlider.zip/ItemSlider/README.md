Simple Multi-Item Slider
=========

A tutorial on how to create a simple category slider with a minimal design using CSS animations and jQuery. The idea is to slide the items sequentially depending on the slide direction.

[article on Codrops](http://tympanus.net/codrops/?p=13218)

[demo](http://tympanus.net/Tutorials/ItemSlider)

Licensed under the MIT License