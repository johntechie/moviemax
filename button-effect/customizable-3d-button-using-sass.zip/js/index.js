/**
 * Note: To customize the button color pass a different background color to the 
 * mixin in line 86
 */