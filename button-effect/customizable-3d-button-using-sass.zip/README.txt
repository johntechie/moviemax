A Pen created at CodePen.io. You can find this one at http://codepen.io/dweidner/pen/arHFo.

 A freaky sass mixin that can be used to create lovely 3d buttons in any color. The button style is based on the work of Dan Cederholm. See the note in the preview for additional information.