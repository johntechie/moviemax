A Pen created at CodePen.io. You can find this one at http://codepen.io/hakimel/pen/ZYRgwB.

 A button that seamlessly transitions into a yes/no confirmation.