A Pen created at CodePen.io. You can find this one at http://codepen.io/rikschennink/pen/lEuLD.

 Prototype for 3D flip button.